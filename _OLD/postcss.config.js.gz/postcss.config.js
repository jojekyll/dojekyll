module.exports = {
    module.exports = {
        use: 'rucksack-css',
        plugins: [
          require('rucksack-css')({ url: 'copy', useHash: true }),
          require('autoprefixer')
        ],
      }
};
